jQuery(function(i){i(".jqFocus,.foswikiFocus").livequery(function(){var o=i(this);window.setTimeout(function(){try{o.focus()}catch(i){}},100)})});
