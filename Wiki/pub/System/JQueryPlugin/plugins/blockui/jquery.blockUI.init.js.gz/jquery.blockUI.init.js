!function(l){l.blockUI.defaults.applyPlatformOpacityRules=!1,l.blockUI.defaults.css={},l.blockUI.defaults.overlayCSS={},l.blockUI.defaults.growlCSS={}}(jQuery);
