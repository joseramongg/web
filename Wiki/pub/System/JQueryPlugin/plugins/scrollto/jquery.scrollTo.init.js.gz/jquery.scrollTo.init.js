"use strict";jQuery(function(t){t(document).on("click",".jqScrollToLink",function(){var n=t(this),c=t.extend({},n.data(),n.metadata());return t.scrollTo(c.target,c),!1})});
