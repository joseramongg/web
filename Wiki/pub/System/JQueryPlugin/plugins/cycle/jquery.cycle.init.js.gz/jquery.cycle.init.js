"use strict";jQuery(function(e){e(".jqCycle:not(.jqInitedCycle)").livequery(function(){var t=e(this),a=e.extend({},t.data(),t.metadata());t.addClass(".jqInitedCycle").cycle(a)})});
