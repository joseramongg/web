"use strict";jQuery(function(a){a(".jqValidate:not(.jqInitedValidate)").livequery(function(){var t=a(this),e=a.extend({},t.data(),t.metadata());t.addClass("jqInitedValidate").validate(e)})});
