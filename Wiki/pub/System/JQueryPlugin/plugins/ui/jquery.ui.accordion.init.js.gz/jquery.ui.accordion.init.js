"use strict";jQuery(function(c){c(".jqUIAccordion").livequery(function(){var e=c(this),o=c.extend({},e.data(),e.metadata());e.removeClass("jqUIAccordion").accordion(o)})});
