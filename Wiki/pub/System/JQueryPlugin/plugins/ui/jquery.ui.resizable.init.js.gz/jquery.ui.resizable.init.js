"use strict";jQuery(function(e){e(".jqUIResizable").livequery(function(){var a=e(this),t=e.extend({},a.data(),a.metadata());a.removeClass("jqUIResizable").resizable(t)})});
