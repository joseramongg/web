"use strict";jQuery(function(t){t(".jqUITabs:not(.jqUITabsInited)").livequery(function(){var a=t(this),e=t.extend({},a.data(),a.metadata());a.addClass("jqUITabsInited").tabs(e)})});
