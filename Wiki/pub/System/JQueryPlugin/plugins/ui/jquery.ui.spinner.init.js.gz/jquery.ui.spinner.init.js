"use strict";jQuery(function(e){e(".jqUISpinner").livequery(function(){var n=e(this),t=(n.val(),e.extend({},n.data(),n.metadata()));n.spinner(t)})});
