jQuery(function(n){n(".jqCorner:not(.jqInitedCorner)").livequery(function(){n(this).addClass("jqInitedCorner").corner()})});
