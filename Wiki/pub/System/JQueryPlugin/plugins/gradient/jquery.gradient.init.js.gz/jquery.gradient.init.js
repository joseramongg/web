"use strict";jQuery(function(t){t(".jqGradient:not(.jqInitedGradient)").each(function(){var a=t(this);a.addClass("jqInitedGradient");var e=t.extend({},a.data(),a.metadata());a.gradient(e)})});
